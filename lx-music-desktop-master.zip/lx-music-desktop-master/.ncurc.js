module.exports = {
  upgrade: true,
  reject: [
    'electron',
    'chalk',
  ],
  // target: 'newest',
  // filter: [
  //   /^vue/,
  //   'electron-builder',
  //   'electron-updater',
  // ],
}
