global.envParams = {}

require('./cmdParams')
require('./screen')
