export function simplify(source: string): string
export function tranditionalize(source: string): string
