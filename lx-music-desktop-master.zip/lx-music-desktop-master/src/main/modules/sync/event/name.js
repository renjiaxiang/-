module.exports = {
  sync_action_list: 'sync_action_list',
  sync_list: 'sync_list',
  sync_handle_list: 'sync_handle_list',
  status: 'status',
}
