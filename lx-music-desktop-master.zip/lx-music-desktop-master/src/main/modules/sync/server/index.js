const { startServer, stopServer, getStatus } = require('./server')

module.exports = {
  startServer,
  stopServer,
  getStatus,
}
