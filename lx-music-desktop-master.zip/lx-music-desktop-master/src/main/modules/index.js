require('./appMenu')
require('./winLyric')
require('./tray')
require('./hotKey')
