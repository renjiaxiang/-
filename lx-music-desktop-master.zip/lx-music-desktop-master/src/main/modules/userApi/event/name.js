module.exports = {
  status: 'status',
  showUpdateAlert: 'showUpdateAlert',
}
