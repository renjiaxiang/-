module.exports = {
  thumbarButtonClick: 'thumbarButtonClick',
}
