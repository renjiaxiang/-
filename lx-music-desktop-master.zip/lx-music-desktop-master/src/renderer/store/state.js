// const isDev = process.env.NODE_ENV === 'development'

export default {
  userInfo: null,
  setting: null,
  settingVersion: null,
}
